package mustafa.muhammedi.ders2

import java.io.Serializable

class Paramedik(val baslik:String, val konu:String, val gorsel:Int) :Serializable {
}